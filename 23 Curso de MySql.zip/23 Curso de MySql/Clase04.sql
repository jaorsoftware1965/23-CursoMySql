# Clase 04
# Insertar Elementos en una tabla con INSERT INTO

# Creamos la Tabla
CREATE TABLE Personas
(
    clave  varchar(5),
    nombre varchar(30),
    edad   tinyint(1),
    genero varchar(1)
);

# Insertamos en la tabla indicando las columnas
INSERT INTO Personas (clave, nombre, edad, genero)
VALUES               ("12345","Juan Perez",34,"M");

# Insertamos en la tabla indicando no todas las columnas
INSERT INTO Personas (clave, nombre, edad)
VALUES               ("12345","Juan Perez",34);

# Insertamos en la tabla indicando con orden distinto
INSERT INTO Personas (nombre,clave,edad)
VALUES               ("juan perez","12345",34);

# Falla si no coinciden la cantidad de columnas
INSERT INTO Personas (nombre,clave,edad,genero)
VALUES               ("juan perez","12345");

# Insertamos en la Tabla sin indicar columnase
INSERT INTO Personas VALUES ("54321","Jose Ramirez",44,"M");
INSERT INTO Personas VALUES ("54321","Jose Ramirez","44","M");

# La Siguiente Falla porque son solo 3 y deben ser 4
INSERT INTO Personas VALUES ("54321","Jose Ramirez",44);
