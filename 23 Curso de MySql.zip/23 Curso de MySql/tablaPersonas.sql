-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.3.16-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Volcando datos para la tabla dbcursomysql.personas: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `personas` DISABLE KEYS */;
INSERT INTO `personas` (`clave`, `nombre`, `edad`, `genero`, `peso`, `estatura`, `fecNac`, `horNac`) VALUES
	('12379', 'Juan Perez', 34, 'M', 50.00, 1.50, '2021-03-24', '16:23:50'),
	('12390', 'Juan Perez', 45, 'M', 50.00, 1.50, '2021-03-24', '16:23:50'),
	('12401', 'juan perez', 56, 'M', 50.00, 1.50, '2021-03-24', '16:23:50'),
	('12412', 'Juan Perez', 67, 'M', 50.00, 1.50, '2021-03-24', '16:23:51'),
	('12423', 'Juan Perez', 78, 'M', 50.00, 1.50, '2021-03-24', '16:23:52'),
	('12368', 'juan perez', 23, 'M', 50.00, 1.50, '2021-03-24', '16:23:52'),
	('12357', 'Juan Perez', 12, 'M', 50.00, 1.50, '2021-03-24', '16:23:53'),
	('12359', 'Juan Perez', 14, 'M', 50.00, 1.50, '2021-03-24', '16:23:53'),
	('12360', 'juan perez', 15, 'M', 50.00, 1.50, '2021-03-24', '16:23:53');
/*!40000 ALTER TABLE `personas` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
