# -------------------------------------------------
# Clase 20
# -------------------------------------------------
# Condicionando Resultados GROUP BY con HAVING

# Contando personas por estado
SELECT estado, COUNT(*)
FROM   domicilio
GROUP BY estado;

SELECT estado, COUNT(*)
FROM   domicilio
WHERE  estado = "Guerrero"
GROUP BY estado;

SELECT estado, COUNT(*)
FROM   domicilio
GROUP BY estado
HAVING estado = "Guerrero";

# Contando personas por estado mayores de 5 en resultados
SELECT estado, COUNT(*)
FROM   domicilio
GROUP BY estado
HAVING COUNT(*) > 5;

# Contando personas por estado que no sean de guerrero
SELECT estado, COUNT(estado)
FROM   domicilio
GROUP  BY estado
HAVING estado = "Guerrero"

SELECT estado, COUNT(estado)
FROM   domicilio
GROUP  BY estado
HAVING estado <> "Guerrero"

# Contando personas agrupando estado, ciudad menores que 5
SELECT estado,ciudad, COUNT(*)
FROM   domicilio
GROUP BY estado, ciudad
HAVING COUNT(*) < 5;

# Sumando personas por estado resultado > 215
SELECT estado, sum(edad)
FROM   domicilio
GROUP BY estado

SELECT estado, sum(edad)
FROM   domicilio
GROUP BY estado
HAVING sum(edad) > 215;

# Contando personas por estado que no sean de guerrero
SELECT estado, SUM(edad)
FROM   domicilio
GROUP  BY estado
HAVING estado <> "Guerrero" ;

SELECT estado, SUM(edad)
FROM   domicilio
GROUP  BY estado
HAVING estado <> "Guerrero" AND sum(EDAD) > 100

SELECT estado, SUM(edad)
FROM   domicilio
WHERE  genero = 'M'
GROUP  BY estado
HAVING estado <> "Guerrero" AND sum(EDAD) > 100

SELECT estado, SUM(edad)
FROM   domicilio
WHERE  genero = 'M' and CIUDAD = "Cordoba"
GROUP  BY estado
HAVING estado <> "Guerrero" 

SELECT estado, SUM(edad)
FROM   domicilio
WHERE  genero = 'F' 
GROUP  BY estado
HAVING max(edad) >79
