
# Clase 01
# Mostrar las Bases de Datos
# Mostrar las Tablas
# Mostrar las Variables

# Muestra las bases de datos en el Servidor
SHOW DATABASES

# Muestra las Tablas
SHOW TABLES

# Muestras las Variables Globales
SHOW VARIABLES