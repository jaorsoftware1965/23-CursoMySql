# -------------------------------------------------
# Clase 25
# -------------------------------------------------
# SubConsultas e Insertando con SELECT

SELECT numero, nombre, edad, carrera,
       (SELECT nombre 
       	FROM   carreras 
       	WHERE  Numero = Carrera) AS carrera
FROM   Estudiantes;

SELECT numero, nombre, edad,
       (SELECT Estado
        FROM   codigosPostales
        WHERE  CodigoPostal = Codigo) AS estado,
       (SELECT Ciudad
        FROM   codigosPostales
        WHERE  CodigoPostal = Codigo) AS ciudad,
       (SELECT Colonia
        FROM   codigosPostales
        WHERE  CodigoPostal = Codigo) AS colonia
FROM   Estudiantes;       


INSERT INTO Estudiantes (Nombre, Genero, Edad, CodigoPostal, Carrera)
SELECT Nombre, Genero, Edad, CodigoPostal, Carrera
FROM   Estudiantes