# Clase 10
# Llaves Unique y Key

# En la clase anterior, vimos que una llave primaria es única 
# y que no puede haber mas que un solo registro que la tenga.

# Solamente puede haber una llave primaria en una tabla, pero 
# Tal vez exista la necesidad de que haya otros campos o columas
# que se necesite que no se repitan

# En una tabla de productos, la llave primaria puede ser el código
# del producto, pero tambien es necesario que el nombre del producto
# no sea repetido, que tambien sea una llave, pero ya no puede ser
# primaria.

# Para indicar que una columna se una llave única, sin ser primaria
# se usan la llave UNIQUE

# Ejemplo:

CREATE TABLE productos 
(
	Codigo VARCHAR(10),
	Nombre VARCHAR(50),
	Existencias TINYINT(4),
	Costo DECIMAL(10,2),
	Precio DECIMAL(10,2),
	Medida VARCHAR(5),
	PRIMARY KEY (Codigo),
	UNIQUE INDEX idxNombre (Nombre)
)
