# Clase 13
# -------------------------------------------------
# ZeroFill
# -------------------------------------------------
create table tblTestZerofill(
	testAutoInc  int      zerofill auto_increment,
	testSmallInt smallint zerofill,
	testDecimal  decimal(10,2) unsigned zerofill,
	testFloat    float    zerofill,
	primary key (testAutoInc)
);

#Insertamos
INSERT INTO tblTestZerofill
VALUES(1,2,3,4,5.6)

# -----------------------------------------------------------
# Operadores Matemáticos
# -----------------------------------------------------------
# Em Sql existen los operadores matemáticos tradicionales
# +,-,* y /
# Los cuales pueden utilizarse con las columnas o con valores
# constantes

# Ejemplo
Select 5 + 8, 5 - 8, 5 * 8, 5 / 8

# -------------------------------------------------
# Creacion de Variable en Ejecución
# -------------------------------------------------

SELECT Codigo, 
       Precio, 
       @PrecioDoble := Precio * 2,
       @PrecioDoble
FROM   Productos

# Ejemplo con una tabla
SELECT Codigo,
       Nombre, 
       Existencias,
       Costo,
	   Precio,
	   @vCosto :=Existencias * Costo AS ValorAlCosto,
	   @vPrecio:=Existencias * Precio AS ValorAlPrecio,
	   @vPrecio - @vCosto AS Utilidad
FROM   Productos		 

SELECT @vCosto :=SUM(Existencias * Costo)  AS ValorAlCosto,
       @vPrecio:=SUM(Existencias * Precio) AS ValorAlPrecio,
  	   @vPrecio - @vCosto AS Utilidad
FROM  PRODUCTOS       

SELECT SUM(Existencias * Costo)   AS ValorAlCosto,
       SUM(Existencias * Precio)  AS ValorAlPrecio,
  	   SUM(Existencias * Precio)-SUM(Existencias * Costo) AS Utilidad
FROM   PRODUCTOS       


SELECT Codigo, Precio, Precio * 2
FROM   Productos

SELECT Codigo, Precio, @X:=Precio * 2+0.0,@X
FROM   Productos

SELECT Codigo,
 Nombre, 
 Existencias,
 Costo,
		 Precio
FROM Productos;



SELECT max(EXISTENCIAS), MIN(EXISTENCIAS) FROM PRODUCTOS

SELECT Codigo, Nombre, Precio - Costo AS Utilidad



#EXTRA
CREATE TABLE `productostest` (
	`numero` INT(11) NOT NULL AUTO_INCREMENT,
	`nombre` VARCHAR(20) NULL DEFAULT '"Producto"',
	`existencia` INT(11) NOT NULL DEFAULT second(curtime()),
	`costo` DECIMAL(10,2) NOT NULL DEFAULT second(curtime()),
	`precio` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
	PRIMARY KEY (`numero`)
)
COLLATE='latin1_swedish_ci'
ENGINE=InnoDB
AUTO_INCREMENT=29
;

#Insertar Primeramente un registro
INSERT INTO productosTest(nombre) values("Producto");

# Despues de unas 20 veces ya tendrás mas de 1 millon
INSERT INTO productosTest(nombre)  SELECT nombre FROM productosTest;


SELECT @vCosto :=SUM(existencia * Costo)  AS ValorAlCosto,
       @vPrecio:=SUM(existencia * Precio) AS ValorAlPrecio,
       @vPrecio - @vCosto AS Utilidad
FROM   productosTest;

SELECT SUM(existencia * Costo)   AS ValorAlCosto,
       SUM(existencia * Precio)  AS ValorAlPrecio,
       SUM(existencia * Precio)-SUM(existencia * Costo) AS Utilidad
FROM   productosTest;


SELECT @vCosto :=SUM(valCosto)  AS ValorAlCosto,
       @vPrecio:=SUM(valPrecio) AS ValorAlPrecio,
  	   @vPrecio - @vCosto AS Utilidad
FROM   productosTest;
