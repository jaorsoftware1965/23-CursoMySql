# Clase 17
# -------------------------------------------------
# Funciones de Fecha
# ------------------------------------------------
Specifier	Description
%a	Abbreviated weekday name (Sun..Sat)
%b	Abbreviated month name (Jan..Dec)
%c	Month, numeric (0..12)
%D	Day of the month with English suffix (0th, 1st, 2nd, 3rd, …)
%d	Day of the month, numeric (00..31)
%e	Day of the month, numeric (0..31)
%f	Microseconds (000000..999999)
%H	Hour (00..23)
%h	Hour (01..12)
%I	Hour (01..12)
%i	Minutes, numeric (00..59)
%j	Day of year (001..366)
%k	Hour (0..23)
%l	Hour (1..12)
%M	Month name (January..December)
%m	Month, numeric (00..12)
%p	AM or PM
%r	Time, 12-hour (hh:mm:ss followed by AM or PM)
%S	Seconds (00..59)
%s	Seconds (00..59)
%T	Time, 24-hour (hh:mm:ss)
%U	Week (00..53), where Sunday is the first day of the week; WEEK() mode 0
%u	Week (00..53), where Monday is the first day of the week; WEEK() mode 1
%V	Week (01..53), where Sunday is the first day of the week; WEEK() mode 2; used with %X
%v	Week (01..53), where Monday is the first day of the week; WEEK() mode 3; used with %x
%W	Weekday name (Sunday..Saturday)
%w	Day of the week (0=Sunday..6=Saturday)
%X	Year for the week where Sunday is the first day of the week, numeric, four digits; used with %V
%x	Year for the week, where Monday is the first day of the week, numeric, four digits; used with %v
%Y	Year, numeric, four digits
%y	Year, numeric (two digits)
%%	A literal % character
%x	x, for any “x” not listed above
# -------------------------------------------------
SELECT DATE_ADD("2013-01-01", INTERVAL 31 DAY),
       DATE_ADD("2013-01-01", INTERVAL 11 MONTH),
       DATE_ADD("2013-01-01", INTERVAL -10 YEAR),
       DATE_ADD("2013-01-01", INTERVAL 1 HOUR),
       DATE_ADD("2013-01-01", INTERVAL 3 MINUTE),
       ADDDATE("2013-01-01" , INTERVAL 3 SECOND);
       
SELECT ADDTIME("23:12:34","12:01:01");
SELECT ADDTIME("1970-01-01 23:12:34","12:01:01");

SELECT CURDATE(), CURRENT_DATE(),CURDATE()+70,CURRENT_DATE()+70;
SELECT CURTIME(), CURRENT_TIME(),CURTIME()+10,CURRENT_TIME()+9;

SELECT CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()+0;

SELECT DATE(NOW()),NOW();
SELECT TIME(NOW()),NOW();

# DIFERENCIA EN DIAS
SELECT DATEDIFF(NOW(),"1965-01-01")/365;

SELECT DATE_FORMAT(NOW(),"%W %m %Y");
SELECT DATE_FORMAT(NOW(),"%H:%i:%s");
SELECT DATE_FORMAT(NOW(),"%D,%y,%a %d %m %b %j");
SELECT DATE_FORMAT(NOW(),"%H,%k,%I %r %T %S %W");


SELECT DAYOFMONTH(NOW()), DAY(NOW());
SELECT DAYOFYEAR(NOW()), year(NOW());

SELECT HOUR(NOW()), MINUTE(NOW()),SECOND(NOW());

# ULTIMO DIA DEL MES
SELECT LAST_DAY(NOW());

# PONES UN AÑO INICIAL Y LE AGREGAS DIAS Y TE DEVUELVE UNA FECHA
SELECT MAKEDATE(2021,138);

# Crear tiempos
SELECT MAKETIME(2,13,12);

SELECT MONTHNAME(NOW());
SELECT MONTHNAME("1995.09.14 19.00.00");
SELECT MONTHNAME(MAKEDATE(2021,138));

# CONVIERTE A HORA UNA CANTIDAD DE SEGUNDOS
SELECT SEC_TO_TIME(60),SEC_TO_TIME(1600);

SELECT STR_TO_DATE("1995.09.14 19.00.00","%Y.%m.%d %H.%i.%s");

# TAMBIEN ACEPTA VALORES NEGATIVOS 
SELECT SUBDATE(NOW(),INTERVAL 1 DAY),
       SUBDATE(NOW(),INTERVAL 3 MONTH),
       SUBDATE(NOW(),INTERVAL 1 YEAR);


SELECT SUBTIME(NOW(),"12:00:00"),
       SUBTIME(NOW(),"09:00:00"),
       SUBTIME(NOW(),"00:06:00");

# CONVIERTE A SEGUNDOS UN TIEMPO
SELECT TIME_TO_SEC("01:00:00");

SELECT TIMEDIFF("12:34:45","12:23:12");

# SUMAR A UNA FECHA , PERMITE NEGATIVOS
SELECT TIMESTAMPADD(MINUTE,1,NOW());
SELECT TIMESTAMPADD(HOUR  ,1,NOW());
SELECT TIMESTAMPADD(SECOND,1,NOW());
SELECT TIMESTAMPADD(WEEK  ,1,NOW());

# OBTENER DIFERENCIAS EN UN INTERVALO ESPECIFICO
SELECT TIMESTAMPDIFF(MONTH,NOW(),"1970-09-14");
SELECT TIMESTAMPDIFF(year ,NOW(),"1970-09-14");

SELECT TO_DAYS("0000-01-01");
SELECT TO_DAYS("1965-09-14");

SELECT WEEKDAY(NOW())

