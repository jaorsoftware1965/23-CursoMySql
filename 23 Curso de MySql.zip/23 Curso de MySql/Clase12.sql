# Clase 12
# Demostrar que no se pueden borrar registros 
# en la tabla de Header si hay registros en el detalle

# Autoincrement y Truncate

# Demostrar que si eliminamos con DELETE el autoincrement
# Continua en el numero que se quedó.
# Si se usa el Truncate Table, se inicia de nuevo en 1

