# Clase 05
# Sentencia SELECT
# Seleccion Registros

# Ejemplos de Sentencia SELECT
SELECT * 
FROM   personas;

SELECT clave, nombre, edad
FROM   personas;

SELECT CONCAT(clave,"-",nombre)
FROM   personas;

# Usando AS 
SELECT CONCAT(clave,"-",nombre) AS cveNombre
FROM   personas;

# Concatenando
SELECT CONCAT(clave,"-",edad) AS cveEdad
FROM   personas;

SELECT CONCAT(clave,"-",edad) AS "Clave y Edad"
FROM   personas;

SELECT COUNT(*) AS Registros 
FROM personas;

SELECT COUNT(Clave)
FROM personas;

SELECT COUNT(genero)
FROM personas;

SELECT COUNT(peso)
FROM personas;

SELECT SUM(edad) 
FROM personas;

SELECT SUM(clave) 
FROM personas;

SELECT SUM(nombre) 
FROM personas;

SELECT MAX(edad), MIN(edad)
FROM   personas;

SELECT replace(nombre,"Perez","[Ramirez]")
FROM personas;

SELECT SUBSTR(Nombre,3) 
FROM   personas;
