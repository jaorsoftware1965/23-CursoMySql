# -------------------------------------------------
# Clase 23
# -------------------------------------------------
# Condicionando Resultados con IF dentro de SELECT

# Usando if para saber mayores de edad
SELECT Numero, Nombre, 
       IF ((edad /2 * 23)>=18,"Mayor Edad","Menor Edad") As Edad,
       Genero, Carrera
FROM   Estudiantes;

SELECT Numero, Nombre,
       IF(edad  >=18,"Mayor Edad","Menor Edad") as Edad, 
       IF(Genero = 'M',"Masculino","Femenino") as Genero,
       Carrera
FROM   Estudiantes;

SELECT   Genero, IF (count(Genero) < 3,"Tiene Menos de 3","Tiene 3 o mas")
FROM     Estudiantes
GROUP By Genero;

SELECT   Genero, IF (avg(Edad) <=18,"Es mehor de Edad el Promedio","Es mayor de Edad el Promedio")
FROM     Estudiantes
GROUP    By Genero;

