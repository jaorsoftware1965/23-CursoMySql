# Clase 03
# Crear, Eliminar y Desplegar la Información de una Tabla
# CREATE TABLE, SHOW TABLES, DESCRIBE Y DROP TABLE

# Ejemplo:
# Tabla: Personas
# clave  nombre         edad  genero
# 34224  Juan Perez     23    M
# 34225  Jose Prado     23    M
# 34224  Maria Morales  23    F

# Creamos la Tabla
CREATE TABLE Personas
(
    clave  varchar(5),
    nombre varchar(30),
    edad   tinyint(1),
    genero varchar(1)
);


# Comando para Describir una Tabla
DESCRIBE Personas;	

#Eliminar la Tabla
DROP TABLE Personas;
