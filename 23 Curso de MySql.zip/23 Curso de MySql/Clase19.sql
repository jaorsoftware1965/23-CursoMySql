# -------------------------------------------------
# Clase 19
# -------------------------------------------------
# AGRUPANDO RESULTADOS CON GROUP BY

# Agrupo por edades y las cuento
SELECT edad, COUNT(*) 
FROM   domicilio 
GROUP BY edad

SELECT edad, COUNT(Estado) 
FROM   domicilio 
GROUP BY edad

# Agrupa por Estado
SELECT estado, COUNT(*) 
FROM   domicilio 
GROUP BY Estado;

# Agrupa por Estado y Ciudad
SELECT estado,ciudad, COUNT(*) 
FROM   domicilio 
GROUP BY Estado, ciudad;

# Agrupa por Estado y Ciudad
SELECT estado,ciudad,colonia, COUNT(*) 
FROM   domicilio 
GROUP BY Estado, ciudad, colonia;

# SUM
SELECT estado, sum(edad) 
FROM   domicilio 
GROUP BY Estado;

SELECT estado, sum(edad) / count(edad)
FROM   domicilio 
GROUP BY Estado;

SELECT estado, ciudad, sum(edad)
FROM   domicilio 
GROUP BY Estado, ciudad;

SELECT estado, ciudad, sum(edad) / count(edad)
FROM   domicilio 
GROUP BY Estado, ciudad;

SELECT estado, avg(edad)
FROM   domicilio 
GROUP BY estado

SELECT estado,MAX(edad), MIN(edad)
FROM   domicilio
GROUP By estado

SELECT estado,ciudad, MAX(edad), MIN(edad)
FROM   domicilio
GROUP By estado, ciudad

SELECT estado,ciudad, MAX(persona), MIN(persona)
FROM   domicilio
GROUP By estado, ciudad

SELECT estado,ciudad, MAX(persona), MIN(persona)
FROM   domicilio
WHERE  edad > 18
GROUP By estado, ciudad
