# Clase 02
# Manejando Bases de Datos
# Crear Eliminar y Activar una Base de Datos

# Creamos una base de datos
CREATE DATABASE myDb

# Usa o Activa una Base de Datos
USE myDb

# Mostramos las Tablas de la Base de Datos
SHOW TABLES

# Elimina una Base de Datos
DROP DATABASE myDb




