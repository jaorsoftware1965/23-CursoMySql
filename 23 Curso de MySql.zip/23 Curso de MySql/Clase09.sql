# Clase 09
# Llaves Primarias

# Una llave primaria es una o mas columnas que unidas crean una
# llave y esta llave no puede estar repetida en la tabla.

# Ejemplo de llaves primarias es por Ejemplo el CURP de una persona.
# Esta llave es ÚNICA y no se puede repetir
# Si se intenta ingresar un registro, y la llave ya existe, no lo
# permitirá y se generará un error.

# Para crear una llave primaria desde Código, se utiliza la sentencia
# PRIMARY KEY  al momento de crear la tabla, y despues de indicar las
# columnas

# Ejemplo:

CREATE TABLE Alumnos
(
	clave  varchar(5),
	nombre varchar(30),
	edad   int(1),
	genero varchar(1),
	primary key (nombre)
);

CREATE TABLE Alumnos
(
	clave  varchar(5),
	nombre varchar(30),
	edad   int(1),
	genero varchar(1),
	primary key (clave,nombre)
);



	



