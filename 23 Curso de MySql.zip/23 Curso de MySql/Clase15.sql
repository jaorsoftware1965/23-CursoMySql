# Clase 15
# -------------------------------------------------
# Limit y Order By
# -------------------------------------------------

SELECT * 
FROM   productos
LIMIT  10;

SELECT * 
FROM   productos
LIMIT  0,10;

SELECT * 
FROM   productos
LIMIT  10,10;

# ORDER BY
SELECT * 
FROM productos
ORDER BY Numero;

SELECT * 
FROM productos
ORDER BY Nombre;

SELECT * 
FROM productos
ORDER BY Marca, Nombre;

SELECT * 
FROM productos
ORDER BY Marca DESC, Precio ASC;
