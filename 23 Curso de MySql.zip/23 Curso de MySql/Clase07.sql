# Clase 07
# UPDATE
# Modificando Registros

# Sintaxis
# UPDATE nombre_tabla
# SET    columna_tabla = valor 
#      [,columna_tabla = valor,...]
# [WHERE Condición]

# Ejemplos
UPDATE personas
SET    peso = 70

UPDATE personas
SET    peso = peso * 1.10

UPDATE personas
SET    peso = 70,
       estatura = 1.82

UPDATE personas
SET    peso = 95
WHERE  estatura >= 1.80

UPDATE personas
SET    fecNac = "1970-01-01"
WHERE  nombre = "Juan Perez"
AND    clave = "12345"

UPDATE personas
SET    edad = YEAR(CURDATE())-YEAR(fecNac)

UPDATE personas
SET    peso = (estatura -1) * 100

SELECT edad, YEAR(CURDATE())-YEAR(fecNac)
FROM PERSONAS

