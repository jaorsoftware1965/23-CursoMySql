# Clase 11
# Llaves Foraneas

# Las llaves foraneas son las que nos permiten establecer relaciones
# entre las tablas

# Pueden esta formadas por una o mas columnas; y debe ser establecidas
# primeramente como llaves, para poder establecerlas como foraneas.

# Las llaves foraneas deben estar definidas de la misma forma en la 
# que se encuentra definida la llave en la tabla en la que se va a
# enlazar

# Ejemplo:

CREATE TABLE `cajeros` (
	`numero` TINYINT(4) NOT NULL,
	`nombre` VARCHAR(50) NULL DEFAULT NULL,
	PRIMARY KEY (`numero`)
)
COLLATE='latin1_swedish_ci'
ENGINE=InnoDB;

CREATE TABLE `ventash` (
	`Folio` INT(11) NOT NULL,
	`Año` CHAR(4) NOT NULL DEFAULT year(curdate()),
	`Fecha` DATE NULL DEFAULT curdate(),
	`Hora` TIME NULL DEFAULT year(curdate()),
	`Caja` TINYINT(4) NULL DEFAULT NULL,
	`Cajero` TINYINT(4) NULL DEFAULT NULL,
	`Articulos` TINYINT(3) UNSIGNED NULL DEFAULT NULL,
	`Total` DECIMAL(10,2) UNSIGNED NULL DEFAULT NULL,
	PRIMARY KEY (`Folio`, `Año`),
	INDEX `FK_ventash_cajeros` (`Cajero`),
	CONSTRAINT `FK_ventash_cajeros` FOREIGN KEY (`Cajero`) REFERENCES `cajeros` (`numero`)
)
COLLATE='latin1_swedish_ci'
ENGINE=InnoDB
;
