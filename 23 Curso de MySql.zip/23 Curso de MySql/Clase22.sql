# -------------------------------------------------
# Clase 22
# -------------------------------------------------
# Left y Right JOIN

# Este select no mostrará los registros de estudiantes
# donde el codigo postal sea null

# Este select NO mostrará los registros de estudiantes
# si el codigo postal sea null
SELECT       nombre, edad, genero, codigoPostal, Estado, Ciudad, Colonia
FROM         estudiantes
INNER JOIN   codigospostales ON estudiantes.codigoPostal = codigospostales.codigo;

# Este select SI mostrará los registros de estudiantes
# aunque el codigo postal sea null
SELECT nombre, edad, genero, codigoPostal, Estado, Ciudad, Colonia
FROM   estudiantes
LEFT   JOIN codigospostales ON estudiantes.codigoPostal = codigospostales.codigo;

# Este select NO mostrará los registros de estudiantes
# si el codigo postal sea null y agregara los codigos sin usar
SELECT nombre, edad, genero, codigoPostal, Estado, Ciudad, Colonia
FROM   codigospostales
LEFT   JOIN estudiantes ON estudiantes.codigoPostal = codigospostales.codigo;


# Estas son las mismas que LEFT JOIN pero con las tablas intercambiadas
SELECT nombre, edad, genero, codigoPostal, Estado, Ciudad, Colonia
FROM   codigospostales
RIGHT  JOIN  estudiantes ON estudiantes.codigoPostal = codigospostales.codigo;

SELECT nombre, edad, genero, codigoPostal, Estado, Ciudad, Colonia
FROM   estudiantes
RIGHT  JOIN  codigospostales ON estudiantes.codigoPostal = codigospostales.codigo;





