# Clase 06
# Select - Where
# Seleccionando Registros con Condiciones
# Utilización de Operadores de Comparación
# Utilización de Operadores Lógicos

# Opertadores de Comparación
# <	 Menor que
# <= Menor o igual que
# >  Mayor que
# >= Mayor o igual que
# <> Distinto que
# =  Igual que

# BETWEEN Entre un intervalo
# LIKE Como
# IN   En

# Operadores Lógicos
# AND 
# OR
# NOT

# Ejemplos
SELECT * 
FROM   personas
WHERE  clave = "12345";

SELECT * 
FROM   personas
WHERE  edad > 34 
AND    genero = 'F';

SELECT * 
FROM   personas
WHERE  edad IN (10,20,30);

SELECT * 
FROM   personas
WHERE  edad NOT in (10,20,30);

SELECT * 
FROM   personas
WHERE  nombre LIKE ("J%");

SELECT * 
FROM   personas
WHERE  edad BETWEEN 43 and 45;

SELECT * 
FROM   personas
WHERE  fecha > '2021-03-10'

