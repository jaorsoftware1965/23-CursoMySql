# -------------------------------------------------
# Clase 21
# -------------------------------------------------
# Haciendo Consultas en mas de una Tabla con WHERE
# y JOIN

# 
SELECT numero, nombre, edad, genero, codigoPostal, carrera
FROM   estudiantes;

# Esto falla porque obtiene el productos cartesiano
SELECT nombre, edad, genero, codigoPostal, 
       Estado, Ciudad, Colonia
FROM   estudiantes, 
       codigospostales

# Esto es lo correcto
SELECT numero, nombre, edad, genero, codigoPostal, carrera,
       codigo, estado, ciudad, colonia
FROM   estudiantes, codigospostales
WHERE  estudiantes.CodigoPostal = codigospostales.codigo;

SELECT numero, nombre, edad, genero, codigoPostal, carrera,
       codigo, estado, ciudad, colonia
FROM   estudiantes
JOIN   codigospostales ON estudiantes.codigoPostal = codigospostales.codigo;


SELECT nombre, edad, genero, codigoPostal, Estado, Ciudad, Colonia
FROM   estudiantes, codigospostales
WHERE  estudiantes.codigoPostal = codigospostales.codigo
AND    codigoPostal = "94500"


SELECT nombre, edad, genero, codigoPostal, Estado, Ciudad, Colonia
FROM   estudiantes
JOIN   codigospostales ON estudiantes.codigoPostal = codigospostales.codigo
AND    codigoPostal = "94500"


SELECT estudiantes.nombre, 
       estudiantes.edad, 
	   estudiantes.genero, 
	   estudiantes.Carrera,
	   carreras.Numero,
       carreras.Nombre 
FROM   estudiantes,  
       carreras
WHERE  estudiantes.carrera = carreras.numero;


SELECT estudiantes.nombre, 
       estudiantes.edad, 
		 estudiantes.genero, 
		 estudiantes.Carrera,
		 carreras.Numero,
		 carreras.Nombre
FROM   estudiantes
JOIN   carreras ON estudiantes.carrera = carreras.numero

SELECT estudiantes.nombre, edad, genero, carreras.Nombre 
FROM   estudiantes,  carreras
WHERE  estudiantes.carrera = carreras.numero;
AND    carrera = 3

SELECT estudiantes.nombre, edad, genero, carreras.Nombre 
FROM   estudiantes
JOIN   carreras
ON     estudiantes.carrera = carreras.numero;
AND    carrera = 3

SELECT estudiantes.nombre, 
       estudiantes.edad, 
		 estudiantes.genero, 
		 estudiantes.Carrera,
		 carreras.Numero,
		 carreras.Nombre 
FROM   estudiantes,  
       carreras
WHERE  estudiantes.carrera = carreras.numero
AND    carreras.numero = 3;

SELECT estudiantes.nombre, 
       estudiantes.edad, 
		 estudiantes.genero, 
		 estudiantes.Carrera,
		 carreras.Numero,
		 carreras.Nombre
FROM   estudiantes
JOIN   carreras ON estudiantes.carrera = carreras.numero
AND    carreras.numero = 3;


SELECT estudiantes.nombre, edad, genero, carreras.Nombre,
       Codigo, Estado, Ciudad, Colonia
FROM   estudiantes,  carreras, codigospostales
WHERE  estudiantes.carrera = carreras.numero
AND    estudiantes.codigoPostal  = codigospostales.codigo

SELECT estudiantes.nombre, edad, genero, carreras.Nombre,
       Codigo, Estado, Ciudad, Colonia
FROM   estudiantes
JOIN   carreras        ON estudiantes.carrera = carreras.numero
JOIN   codigospostales ON estudiantes.codigoPostal = codigospostales.codigo

# Usando Alias
SELECT E.nombre, edad, genero, C.Nombre,
       Codigo, Estado, Ciudad, Colonia
FROM   estudiantes     AS E
JOIN   carreras        AS C ON E.carrera      = C.numero
JOIN   codigospostales AS P ON E.codigoPostal = P.codigo






