# -------------------------------------------------
# Clase 24
# -------------------------------------------------
# Condicionando Resultados con CASE dentro de SELECT

# Usando CASE
SELECT Numero, Nombre, 
       CASE Genero
            WHEN "M" THEN "Masculino"
            WHEN "F" THEN "Femenino"
            ELSE "No lo tiene indicado"
       END 
       Genero, Carrera
FROM   Estudiantes;

SELECT Numero, Nombre, 
       CASE 
            WHEN Genero = "M" THEN "Masculino"
            WHEN Genero = "F" THEN "Femenino"
            ELSE "Nuevo Genero"
       END 
       Genero, Carrera
FROM   Estudiantes;

SELECT Numero, Nombre, Genero, Edad,
       CASE 
            WHEN Edad<=18 THEN "Joven"
            WHEN Edad<=50 THEN "Adulto"
            WHEN Edad<=70 THEN "Mayor"
            ELSE "Jubilado"
       END
       Edad, Carrera
FROM   Estudiantes;

SELECT Numero, Nombre, Genero, Edad,
       CASE 
            WHEN Edad<=3  THEN "Bebe"
            WHEN Edad<=12 THEN "Niño"
            WHEN Edad<=18 THEN "Joven"
            WHEN Edad<=50 THEN "Adulto"
            WHEN Edad<=70 THEN "Mayor"
            ELSE               "Jubilado"
       END Edad, 
             Carrera
FROM   Estudiantes;

SELECT Numero, 
       Nombre, 
             Genero, 
             Edad,
       CASE 
            WHEN Edad<= 3 THEN "Bebe"
            WHEN Edad<=11 THEN "Niño"
            WHEN Edad<=15 THEN "Adolescente"
            WHEN Edad<=18 THEN "Joven"
            WHEN Edad<=50 THEN "Adulto"
            WHEN Edad<=70 THEN "Mayor"
            ELSE "Jubilado"
       END EtapaVida, 
             Carrera
FROM   Estudiantes;