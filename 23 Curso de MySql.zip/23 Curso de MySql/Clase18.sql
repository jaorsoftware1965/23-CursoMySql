# -------------------------------------------------
# Clase 18
# -------------------------------------------------
# OPERACIONES CON REGISTROS
# COUNT. Cuenta regisrtos que no sean numeros

# Contara todos los registros
SELECT COUNT(*) FROM domicilio;

# Contara los que no sean nulos  
SELECT COUNT(ESTADO) FROM domicilio; 

# Selecciona distintos
SELECT DISTINCT(ESTADO) FROM DOMICILIO;

# Contara los estados distintos
SELECT COUNT(DISTINCT(ESTADO)) FROM domicilio;

# Contara las ciudades distintas
SELECT COUNT(DISTINCT(ciudad)) FROM domicilio;
SELECT COUNT(DISTINCT(NUMERO)),COUNT(DISTINCT(PERSONA))
FROM   domicilio;


# SUM SOBRE DATOS NO NUMERICOS DEVUELVE 0
SELECT SUM(EDAD)           from domicilio;
SELECT SUM(DISTINCT(EDAD)) FROM DOMICILIO;

#AVG
SELECT AVG(EDAD)            FROM DOMICILIO;
SELECT AVG(DISTINCT(EDAD))  FROM DOMICILIO;


# MAX Y MIN
# NUMERICAMENTE
SELECT MAX(EDAD), MIN(EDAD) FROM domicilio;

# ALFABETTICAMENTE
SELECT MAX(fechaAlta), MIN(fechaAlta) from productos;



