# Clase 14
# -------------------------------------------------
# Variables
# -------------------------------------------------

# En la clase anterior vimos como definir una variable
# al momento de realizar una consulta.
# Las variables se pueden definir antes

# Ejemplos
set @cantidad = 200;
set @iva      = 1.15;
set @sistema  = "Inventario";
SET @prefijo  = "Sr"
SET @moneda   = "$";

SELECT @cantidad,@iva, @sistema;
SELECT (89 + @cantidad) * (1 + @iva);
SELECT CONCAT(@prefijo,"Juan Perez");

SELECT numero, nombre,CONCAT(@moneda,precio), CONCAT(@moneda, precio * @iva)
FROM   PRODUCTOS


# -------------------------------------------------------
# Funciones Matemáticas
# -------------------------------------------------------
select abs(-67)                   AS Absoluto;
select ceiling(1.490)             AS RedondeaArriba;
select floor(1.490)               AS RedondeaAbajo;
select greatest(-4,-65,-12,-5)    AS ElMayor;
select least(-4,-65,-12,-5)       AS ElMenor;
select mod(36,5)                  AS ElResiduo;
select 36 % 5                     AS ElResiduo2;
select pow(3,4)                   AS Potencia;
select sqrt(81)                   AS Raiz;
select rand()                     AS Aleatorio1;
select rand()                     AS Aleatorio2;
select round(12.49)               AS Redondea1;
select round(12.51)               AS Redondea2;
select truncate(1234.567,0)       AS Trunca1;
select truncate(1234.567,2)       AS Trunca2;

