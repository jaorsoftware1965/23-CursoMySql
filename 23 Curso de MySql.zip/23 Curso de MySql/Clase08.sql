# Clase 08
# DELETE FROM
# Eliminando Registros

# Sintaxis
# DELETE FROM nombre_tabla
# [WHERE Condición]

# Ejemplos
DELETE FROM personas
WHERE  estatura >= 1.80

DELETE FROM personas
WHERE  nombre = "Juan Perez"
AND    clave = "12345"

DELETE FROM personas
WHERE  nombre LIKE ("J%")

DELETE FROM personas
WHERE  edad BETWEEN 45 and 60;

DELETE FROM personas
WHERE  edad IN (45,60);

DELETE FROM   personas
WHERE  edad > 34 
AND    genero = 'F';

DELETE FROM   personas
WHERE  MONTH(fecNac) = 5 

DELETE FROM   personas
WHERE  DAY(fecNac) = 25 
